
---
<br><br><br><br><br><br><br><br>
<tt>title&nbsp;&nbsp;: NIIC(DA) 構成管理運用手順書
<tt>ver&nbsp;&nbsp;&nbsp;&nbsp;: 1.0.0</tt>  
<tt>date&nbsp;&nbsp;&nbsp;: 2022/03/24</tt>  
<tt>author&nbsp;: 伊藤忠テクノソリューションズ</tt>  
---

<div style="page-break-before:always"></div>

# 改版履歴

|版名|改定者|改定日|改定ページ|改定内容|備考|
|:-:|:-:|:-:|:--|:--|:--|
|初版|CTC|2022/03/24|||初版作成|
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||

<div style="page-break-before:always"></div>

# 目次
  &nbsp;&nbsp;[はじめに](#anchor0)
  &nbsp;&nbsp;1.[リポジトリとは](#anchor1)
  &nbsp;&nbsp;&nbsp;&nbsp;1.1[NIIC(DA)のリポジトリ](#anchor1.1)
  &nbsp;&nbsp;&nbsp;&nbsp;1.2[NIIC(DA)のリポジトリの関係](#anchor1.2)
  &nbsp;&nbsp;&nbsp;&nbsp;1.3[NIIC(DA)のラインブランチ](#anchor1.3)
  &nbsp;&nbsp;&nbsp;&nbsp;1.4[SourceTreeのラインブランチの取込](#anchor1.4)
  &nbsp;&nbsp;&nbsp;&nbsp;1.5[商用リリース物件](#anchor1.5)
  &nbsp;&nbsp;2.[マスターリポジトリの更新](#anchor2)
  &nbsp;&nbsp;3.[その他](#anchor3)
  &nbsp;&nbsp;&nbsp;&nbsp;3.1[構成管理業務の変更点](#anchor3.1)
  
<div style="page-break-before:always"></div>

<a id="anchor0"></a>

## はじめに

&nbsp;&nbsp;このドキュメントは、NIIC(DA)構成管理のソース管理から商用リリースまでの運用手順について説明します。

>Git（ギット）は、プログラムのソースコードなどの変更履歴を記録・追跡するための<b>分散型バージョン管理システム</b>である。Linuxカーネルのソースコード管理に用いるためにリーナス・トーバルズによって開発され、それ以降ほかの多くのプロジェクトで採用されている。Linuxカーネルのような巨大プロジェクトにも対応できるように、動作速度に重点が置かれている。現在のメンテナは濱野純 (英語: Junio C Hamano/Google) で、2005年7月から担当している。
出典: フリー百科事典『ウィキペディア（Wikipedia）』

<div style="page-break-before:always"></div>

<a id="anchor1"></a>

## 1. リポジトリとは

&nbsp;&nbsp;ソース管理はGit上でプロジェクトを作って管理をします。このプロジェクトのことをリポジトリといいます。リポジトリには<b>リモートリポジトリ</b>と<b>ローカルリポジトリ</b>の2種類があります。

![](2022-02-21-10-13-22.png)

&nbsp;&nbsp;GitHubやGitLab、またはリモートサーバで作ったリポジトリのことをリモートリポジトリといいます。リモートリポジトリがあるだけでは作業はできません。リモートのバージョンをコピーしたものをローカルに持って行かないと作業ができないのです。

※1 ローカルからリモートへ登録(push)、同期(fetch)、取得(pull)でソースをやり取りします。このリモートからローカルにコピーすることをクローンと呼びます。

※2 リモートリポジトリは共有して使用するリポジトリなので、<b>ベアリポジトリ</b>と呼びます。
これに対して、ローカルリポジトリを<b>ノンベアリポジトリ</b>と呼びます。

※3 リポジトリの単位はディレクトリです。このディレクトリにGitの管理ファイルが設定されています。

<div style="page-break-before:always"></div>

<a id="anchor1.1"></a>

### 1.1 NIIC(DA)のリポジトリ

* リポジトリの配置ディレクトリ

サーバー     : nidsvr01b
ディレクトリ : /export/home/smc/source/git
ユーザー     : source

|№|システム名称|ノンリポジトリ|ベアリポジトリ|備考|
|:-:|:--|:--|:--|:--|
|1|aegis|aegis|aegis.git| |
|2|area|area|area.git| |
|3|bb-self-b|bb-self-b|bb-self-b.git| |
|4|common|common|common.git|共通|
|5|custody|custody|custody.git| |
|6|dnyu|dnyu|dnyu.git|移行導入ツール|
|7|docs-ment|docs-ment|docs-ment.git| |
|8|guide|guide|guide.git| |
|9|gw|gw|gw.git| |
|10|isp|isp|isp.git| |
|11|keiyaku|keiyaku|keiyaku.git|契約|
|12|kengen|kengen|kengen.git| |
|13|kokuchi|kokuchi|kokuchi.git|告知|
|14|kss|kss|kss.git| |
|15|malimo|malimo|malimo.git| |
|16|necat|necat|necat.git| |
|17|nreturn|nreturn|nreturn.git| |
|18|proxy|proxy|proxy.git| |
|19|search|search|search.git| |
|20|see-g|see-g|see-g.git| |
|21|selfpage|selfpage|selfpage.git| |
|22|signup2|signup2|signup2.git| |
|23|smc-b|smc-b|smc-b.git| |
|24|snsyou|snsyou|snsyou.git| |
|25|ssif|ssif|ssif.git| |
|26|sso-api|sso-api|sso-api.git| |
|27|sso-self|sso-self|sso-self.git| |
|28|tmdm|tmdm|tmdm.git| |
|29|tobila|tobila|tobila.git| |
|30|tuuchi|tuuchi|tuuchi.git| |
|31|unyou|unyou|unyou.git| |
|32|voip|voip|voip.git| |

※1 2022/03/14、NIIC(DA)の全サーバーから取得したアプリを上記のシステムに割り当て、
Javaのソースとmake用のソースをそれぞれに割り振っています。

※2 ノンリポジトリにアプリとソースの実ファイルが配置されています。
リポジトリはディレクトリなので、Linuxの通常コマンドを使用して、ファイルを検索可能です。

ssifのmakeソースディレクトリを検索(nidsr01b /export/home/smc/source/git/)
```Shell
$pwd
/export/home/smc/source/git
$ find ssif -name make
ssif/nidams/smc/make
```

※3 ベアリポジトリをローカルPCにCloneしたローカルリポジトリでソースを編集することになります。

ベアリポジトリssifのソースをローカルPCへclone(検証PCのGit Bashターミナル)
```Shell
$ cd Dcocuments
$ cd git  # Cocuments/gitに移動
$ git clone ssh://10.47.70.10/export/home/smc/source/git/ssif.git
$ ls
  ssif # ssifディレクトリが作成されソース一式が取得される
```

<div style="page-break-before:always"></div>

<a id="anchor1.2"></a>

### 1.2 NIIC(DA)のリポジトリの関係


![](2022-03-24-10-00-05.png)


・ローカルで作業するために、nidsvr01bからベアリポジトリをローカルへcloneします。
一度cloneすれば、サーバー側の最新状態を手に入れるには、SourceTreeでpullします。

・ローカルでソースを編集します。
ソース編集 → 作業ツリー → インデックスへ追加 → commit

・SourceTreeを利用して編集したソースをベアリポジトリへpushします。

<div style="page-break-before:always"></div>

<a id="anchor1.3"></a>

### 1.3 NIIC(DA)のラインブランチ

&nbsp;&nbsp;ラインとは、NIIC(DA)の商用リリースラインのことです。
&nbsp;&nbsp;ラインブランチは商用リリースソースの修正と商用リリース物件を配置するリポジトリになります。
&nbsp;&nbsp;システム名と同じ名称のベアリポジトリはソース参照用として使用します。


&nbsp;&nbsp;<b>2022/08</b>で商用リリースするssif案件の開発用リポジトリを作成する場合、
<b>ssif_2208.git</b>のラインブランチ(ベアリポジトリ)を作成します。

&nbsp;&nbsp;平行して、<b>2022/09</b>で商用リリースするssif案件の開発用リポジトリを作成する場合、
<b>ssif_2209.git</b>のラインブランチ(ベアリポジトリ)を作成します。

どのラインブランチも<b>ssif.gitからclone</b>して作成されます。

![](2022-03-24-13-17-13.png)

&nbsp;&nbsp;このラインブランチ作成は、NIIC(DA)の検証アカウント所有者が作成できます。
&nbsp;&nbsp;作成した場合、構成管理tocaroに、作成した<b>リポジトリ名、案件番号、案件内容、作成年月日、作成者、リリース日</b>を記入してください。
&nbsp;&nbsp;構成管理の<b>リポジトリ管理台帳</b>へ内容を転機して管理します。

<a id="anchor1.4"></a>

### 1.4 SourceTreeのラインブランチの取込

前節のラインブランチのclone後のディレクトリをSourceTreeに登録します。
エクスプローラーからSourceTreeへドラッグアンドドロップします。

![](2022-03-24-14-09-48.png)

![](2022-03-24-14-09-23.png)

<div style="page-break-before:always"></div>

ラインブランチをダブルクリックすると、リポジトリ毎にタブが表示されます。
商用リリースのライン単位でソースの修正を行い、リモートリポジトリへpushします。

![](2022-03-24-14-16-10.png)

※1 ソース編集については、「14.NIIC(DA)構成管理操作手順書_20220324-01C.pdf」を参照してください。

<div style="page-break-before:always"></div>

<a id="anchor1.5"></a>

### 1.5 商用リリース物件

&nbsp;&nbsp;ソースの修正後、すべての変更内容をpushでラインブランチ（リモートリポジトリ）を更新します。
&nbsp;&nbsp;商用リリース物件のリストを作成する必要があります。
&nbsp;&nbsp;下記はssifの2208RLのラインリリースを例にしています。
&nbsp;&nbsp;<b>リリース連絡票</b>を起票します。

![](2022-03-25-07-06-27.png)


起票したリリース連絡票を移行導入・構成管理宛てに提出します。
受領したリリース連絡票から物件リストのcsvを作成し、nidsvr01bの検証環境にて、
商用リリース物件をssif_2208.gitより取得して、商用リリース物件を作成します。
商用リリース物件作成完了後、開発担当へ<b>商用物件作成完了の連絡</b>を行います。

<div style="page-break-before:always"></div>

<a id="anchor2"></a>

## 2. マスターリポジトリの更新

&nbsp;&nbsp;商用リリース後のラインブランチをもとにベアリポジトリとノンベアリポジトリを更新します。
&nbsp;&nbsp;月末から月初にかけて更新する予定です。

![](2022-03-26-10-47-52.png)

&nbsp;&nbsp;タグを参照することでベアリポジトリのバージョンを確認することができます。
&nbsp;&nbsp;どの商用リリースと同期が取れているかを判断できます。
&nbsp;&nbsp;ssif_2208.gitとssif_2209.gitで同じソースを変更している場合、コリジョンが発生する可能性があります。
&nbsp;&nbsp;更新する前に、必ずコリジョンチェックを行い（ファイル単位で同件をチェックします）取込みの可否をチェックします。

<div style="page-break-before:always"></div>

<a id="anchor3"></a>

## 3. その他

&nbsp;&nbsp;今回の構成管理ツール化にともなう変更点についてまとめます。

<a id="anchor3.1"></a>

### 3.1 構成管理業務の変更点

* ソースの受払業務はありません
&nbsp;&nbsp;開発者みずから、SourceTreeを使用してソースやリリース物件を作成し、ラインブランチを完成させます。
&nbsp;&nbsp;案件のリリースリストを作成するために、リリース連絡票は起票します。
&nbsp;&nbsp;これをもとに商用リリース物件を作成します。

* ソースのタイムスタンプ
&nbsp;&nbsp;現行はファイルの保存したタイムスタンプで管理してきました。
&nbsp;&nbsp;Git移行により、Gitの管理がファイルをcommitした日時を元にしているため、移行後のファイルはcommitした日時で管理します。

* ソースとドキュメントの管理を一体化できる
&nbsp;&nbsp;新規案件などまったく新しいシステムを先行して作成することができます。
&nbsp;&nbsp;開発者が作成しているドキュメントの版管理が容易にできるようになります。
&nbsp;&nbsp;Git Bashで新しいGitのプロジェクト(NewPJ)を作成してみます。

```shell
$ cd ~/Documents/git
$ make NewPJ
$ cd NewPJ
$ git init
```

&nbsp;&nbsp;このコマンドで新しいプロジェクトリポジトリ（ローカルリポジトリ）ができます。
&nbsp;&nbsp;このディレクトリをSourceTreeにドラッグすることでSourceTreeにて管理が可能になります。
&nbsp;&nbsp;※ 1.4 SourceTreeのラインブランチの取込を参照

&nbsp;&nbsp;以降は、このNewPjディレクトリへソースやドキュメントファイルを配置していくことで、すべてのファイルをGit管理下にできます。

&nbsp;&nbsp;この新しいプロジェクトリポジトリを運用管理へ公開してマスター化することも可能となります。





