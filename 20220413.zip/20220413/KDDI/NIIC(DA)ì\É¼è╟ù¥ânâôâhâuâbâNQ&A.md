
---
<br><br><br><br><br><br><br><br>
<tt>title&nbsp;&nbsp;: NIIC(DA) 構成管理Q&Aハンドブック
<tt>ver&nbsp;&nbsp;&nbsp;&nbsp;: 1.0.0</tt>  
<tt>date&nbsp;&nbsp;&nbsp;: 2022/04/04</tt>  
<tt>author&nbsp;: 伊藤忠テクノソリューションズ</tt>  
---

<div style="page-break-before:always"></div>

# 改版履歴

|版名|改定者|改定日|改定ページ|改定内容|備考|
|:-:|:-:|:-:|:--|:--|:--|
|初版|CTC|2022/04/04|||初版作成|
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||
|<br>|||||

<div style="page-break-before:always"></div>

# 目次
  &nbsp;&nbsp;[はじめに](#anchor0)
  &nbsp;&nbsp;1.[リポジトリとは](#anchor1)
  &nbsp;&nbsp;&nbsp;&nbsp;1.1[NIIC(DA)のリポジトリ](#anchor1.1)
  &nbsp;&nbsp;&nbsp;&nbsp;1.2[NIIC(DA)のリポジトリの関係](#anchor1.2)
  &nbsp;&nbsp;&nbsp;&nbsp;1.3[NIIC(DA)のラインブランチ](#anchor1.3)
  &nbsp;&nbsp;&nbsp;&nbsp;1.4[SourceTreeのラインブランチの取込](#anchor1.4)
  &nbsp;&nbsp;&nbsp;&nbsp;1.5[商用リリース物件](#anchor1.5)
  &nbsp;&nbsp;2.[マスターリポジトリの更新](#anchor2)
  &nbsp;&nbsp;3.[その他](#anchor3)
  &nbsp;&nbsp;&nbsp;&nbsp;3.1[構成管理業務の変更点](#anchor3.1)
  
<div style="page-break-before:always"></div>

<a id="anchor0"></a>

## はじめに

&nbsp;&nbsp;このドキュメントは、NIIC(DA)構成管理のツールを使用するためQ&A集のハンドブックです。
&nbsp;&nbsp;Gitの基本操作を学習し、NIIC(DA)構成管理のツールを使いこなすための手引きです。

>Git（ギット）は、プログラムのソースコードなどの変更履歴を記録・追跡するための<b>分散型バージョン管理システム</b>である。Linuxカーネルのソースコード管理に用いるためにリーナス・トーバルズによって開発され、それ以降ほかの多くのプロジェクトで採用されている。Linuxカーネルのような巨大プロジェクトにも対応できるように、動作速度に重点が置かれている。現在のメンテナは濱野純 (英語: Junio C Hamano/Google) で、2005年7月から担当している。
出典: フリー百科事典『ウィキペディア（Wikipedia）』

<div style="page-break-before:always"></div>

### 1.nidsvr01b(検証運用管理サーバー）にログインする

&nbsp;&nbsp;リモートリポジトリを作成するためには、nidsvr01bにTeratermでログインする必要があります。
&nbsp;&nbsp;検証の端末にログインする場合を想定します。

> ホスト(T):10.47.70.10を指定

![](2022-04-05-14-43-08.png)

> ユーザ名(N): P番またはS番アカウントを入力
パスフレーズ(P): パスワードを入力

![](2022-04-05-14-45-03.png)

<div style="page-break-before:always"></div>

P番でログインしました。

![](2022-04-05-15-08-18.png)

suコマンドを利用するため[Znid9900]アカウントにssh接続します。

> ssh Znid9900@localhost

![](2022-04-05-15-11-59.png)

<div style="page-break-before:always"></div>

> Znid9900@local's password: Guest001!

![](2022-04-05-15-15-17.png)

sourceアカウントにスイッチします。

> su - source

![](2022-04-06-09-26-35.png)

<div style="page-break-before:always"></div>

sourceアカウントのパスワードを入力します。

> パスワード:admyymm
※ adm + 西暦下２桁 + 月

![](2022-04-06-10-40-26.png)

sourceアカウントのホームディレクトリは「/export/home/smc」です。
gitのリポジトリは「/export/home/smc/source/git」になります。

> cd source/git

![](2022-04-06-10-43-38.png)

<div style="page-break-before:always"></div>

lsでリポジトリを確認します。

> ls -l

![](2022-04-06-11-02-16.png)

<div style="page-break-before:always"></div>

### 2.ローカルリポジトリを作成する。

#### 2.1 リポジトリの初期化

リポジトリは下記の手順で作成します。

サーバー：nidsvr01b(10.47.70.10)
ディレクトリ：/export/home/smc/source/git
ユーザ:source ※SourcetreeからのアクセスはP番またはS番

下記は「mylocal」ローカルリポジトリを作成する例
※講習では、各自の名前を作成してください。

```shell
$ cd source/git
$ pwd
/export/home/smc/source/git
$ mkdir mylocal
$ cd mylocal
$ pwd
/export/home/smc/source/git/mylocal
$ git init   # 初期化
Initialized empty Git repository in /export/home/smc/source/git/mylocal/.git/
$ ls -la
合計 12
drwxrwxr-x  3 source smc 4096  4月 11 08:55 .
drwxrwxr-x 20 source smc 4096  4月 11 08:55 ..
drwxrwxr-x  7 source smc 4096  4月 11 08:55 .git
```

> git init

ディレクトリにGitのリポジトリ管理のディレクトリと管理ファイルを作成します。

<div style="page-break-before:always"></div>

#### 2.2 ファイルを追加する

&nbsp;&nbsp;2.1で作成したリポジトリへファイルを追加します。

```shell
$ pwd
/export/home/smc/source/git/mylocal
$ vi sample.txt
2022/4/22
$ ls
sample.txt
$ git log
fatal: your current branch 'master' does not have any commits yet
```

> git log

Gitの操作ログを表示します。

まだ、なにもGitに対して操作していないので、「does not have any commit yet」になります。
Gitに管理へ追加するには、Gitのインデックスに追加する必要があります。

```shell
$ git add sample.txt
$ git status
ブランチ master

No commits yet

コミット予定の変更点:
  (use "git rm --cached <file>..." to unstage)
        new file:   sample.txt
```

> git add ファイル名

Gitのインデックスに変更したファイルを追加します。
ファイル名だけの場合、個別のファイルだけを追加します。

> git add .

Gitのインデックスに変更点をすべて追加します。
複数の変更した場合はこれで行います。

> git status

「現在の状況を確認する」ためのコマンドです。具体的にはファイルの追加や修正、addでインデックスに登録など、現在どのような状態かを確認することができます。

<div style="page-break-before:always"></div>

#### 2.3 ファイルをcommitする

&nbsp;&nbsp;2.2 でインデックスに追加した「sample.txt」をcommitします。
&nbsp;&nbsp;commitするためにた、必ず、コメントを付ける必要があります。
&nbsp;&nbsp;コメントは変更した目的など、後で検索しやすいコメントを付けます。

```shell
$ git commit -m "sample.txt add 20220411"
[master (root-commit) c4c9943] sample.txt add 20220411
 1 file changed, 1 insertion(+)
 create mode 100644 sample.txt
 ```

> git commit -m "コメント"

インデクスに登録した変更点をcommitします。
-m "コメント"はcommitのコメントを指定します。

```shell
$ git log
commit c4c9943286cb88539d306ac3b07661409f7f843b (HEAD -> master)
Author: pooshikin <smc-admin@ctc-g.co.jp>
Date:   Mon Apr 11 09:21:55 2022 +0900

    sample.txt add 20220411
```

> git log

commit後のlog内容です。コメントが表示されます。

<div style="page-break-before:always"></div>

* よく使うlogのオプション

|オプション|機能|
|:--|:--|
|--stat|ログとともに、どのファイルが何カ所変更されたのかを表示する|
|--name-only|ログとともに、変更されたファイルの名前のみを表示する|
|--oneline|各コミットを1行で簡潔に表示する|

```shell
$ git log --stat
commit c4c9943286cb88539d306ac3b07661409f7f843b (HEAD -> master)
Author: pooshikin <smc-admin@ctc-g.co.jp>
Date:   Mon Apr 11 09:21:55 2022 +0900

    sample.txt add 20220411

 sample.txt | 1 +
 1 file changed, 1 insertion(+)
```

```shell
$ git log --name-only
commit c4c9943286cb88539d306ac3b07661409f7f843b (HEAD -> master)
Author: pooshikin <smc-admin@ctc-g.co.jp>
Date:   Mon Apr 11 09:21:55 2022 +0900

    sample.txt add 20220411

sample.txt
```

```shell
$ git log --oneline
c4c9943 (HEAD -> master) sample.txt add 20220411
```

<div style="page-break-before:always"></div>

#### 2.4 ファイルを修正する

&nbsp;&nbsp;2.3でcommitした「sample.txt」を編集します。

```shell
$vi sample.txt
2022/04/11
update 2022/04/13
$ git add .
$ git status
ブランチ master
コミット予定の変更点:
  (use "git restore --staged <file>..." to unstage)
        modified:   sample.txt

$ git commit -m "update 20220413"
[master 6607905] update 20220413
 1 file changed, 1 insertion(+)
$ git log --oneline
6607905 (HEAD -> master) update 20220413
c4c9943 sample.txt add 20220411
```

commitまで完了しました。

#### 2.5 ファイルをコピーおよび編集する

sample.txtをコピーしてsample2.txtを作成します。

```shell
$ cp -ip sample.txt sample2.txt
$ ls
sample.txt  sample2.txt
$ vi sample2.txt
2022/04/11
update 2022/04/13
rename sample2.txt
$ git add .
$ git status
ブランチ master
コミット予定の変更点:
  (use "git restore --staged <file>..." to unstage)
        new file:   sample2.txt

$ git commit -m "sample2.txt add 20220413"
[master 68f5794] sample2.txt add 20220413
 1 file changed, 3 insertions(+)
 create mode 100644 sample2.txt
$ git log --oneline
68f5794 (HEAD -> master) sample2.txt add 20220413
6607905 update 20220413
c4c9943 sample.txt add 20220411
```

#### 2.6 新しいディレクトリを作成してファイル移動

```shell
$ mkdir backup
$ ll
合計 24
drwxrwxr-x  4 source smc 4096  4月 11 12:07 ./
drwxrwxr-x 20 source smc 4096  4月 11 08:55 ../
drwxrwxr-x  8 source smc 4096  4月 11 11:55 .git/
drwxrwxr-x  2 source smc 4096  4月 11 12:07 backup/
-rw-rw-r--  1 source smc   29  4月 11 11:48 sample.txt
-rw-rw-r--  1 source smc   48  4月 11 11:54 sample2.txt
$ mv sample.txt backup/.
$ git add .
$ git status
ブランチ master
コミット予定の変更点:
  (use "git restore --staged <file>..." to unstage)
        renamed:    sample.txt -> backup/sample.txt

$ git commit -m "mv sample.txt to backup 20220413"
[master 9dcd2c2] mv sample.txt to backup 20220413
 1 file changed, 0 insertions(+), 0 deletions(-)
 rename sample.txt => backup/sample.txt (100%)
$ git log --oneline
9dcd2c2 (HEAD -> master) mv sample.txt to backup 20220413
68f5794 sample2.txt add 20220413
6607905 update 20220413
c4c9943 sample.txt add 20220411
```

<div style="page-break-before:always"></div>

### 3.Sourcetreeを使う

&nbsp;&nbsp;2章で作成したmylocalからリモートリポジトリを作成し、ローカルPCにリモートリポジトリをcloneします。

#### 3.1 mylocalリモートリポジトリ作成

&nbsp;&nbsp;リモートリポジトリは <b>「--bareと--Shared=true」</b>で作成します。
&nbsp;&nbsp;ローカルリポジトリにリモートリポジトリのURL(ディレクトリ）を登録することで「push/pull」のコマンドの宛先が登録されます。
&nbsp;&nbsp;※Sourcetreeのpush/pullも内部でこの宛先が登録されます。

```shell
$ mkdir mylocal.git
$ cd  mylocal.git
$ pwd
/export/home/smc/source/git/mylocal.git
$ git init --bare --shared=true
Initialized empty shared Git repository in /export/home/smc/source/git/mylocal.git/
$ cd ../mylocal
$ pwd
/export/home/smc/source/git/mylocal
$ git remote add origin /export/home/smc/source/git/mylocal.git/
$ git remote -v
origin  /export/home/smc/source/git/mylocal.git/ (fetch)
origin  /export/home/smc/source/git/mylocal.git/ (push)
$ git push origin master
Enumerating objects: 11, done.
Counting objects: 100% (11/11), done.
Compressing objects: 100% (6/6), done.
Writing objects: 100% (11/11), 1014 bytes | 1014.00 KiB/s, done.
Total 11 (delta 0), reused 0 (delta 0)
To /export/home/smc/source/git/mylocal.git/
 * [new branch]      master -> master
 ```

> git init --bare --shared=true

リモートリポジトリを初期化します。

>  git remote add origin /export/home/smc/source/git/mylocal.git/

ローカルリポジトリにpush先originのディレクトリ(URL)を登録します。

> git remote -v

リモートリポジトリの宛先を表示します。

> git push origin master

ローカルリポジトリmaterをリモートリポジトリoriginへpushします。

<div style="page-break-before:always"></div>

#### 3.2 Git Bashでリモートリポジトリのclone

```shell
$ git clone ssh://nidsvr01b/export/home/smc/source/git/mylocal.git
Cloning into 'mylocal'...
Pxxxxxx@nidsvr01b's password:
remote: Enumerating objects: 11, done.
remote: Counting objects: 100% (11/11), done.
remote: Compressing objects: 100% (6/6), done.
remote: Total 11 (delta 0), reused 0 (delta 0)
Receiving objects: 100% (11/11), done.
```

> git clone ssh:/IP or URL /リモートリポジトリのディレクトリ

![](2022-04-11-13-44-49.png)

上はDocuments/gitにclone後にリモートリポジトリから「mylocal」ディレクトリがコピーされます。

<div style="page-break-before:always"></div>

#### 3.3 Sourcetreeにローカルリポジトリを登録

&nbsp;&nbsp;Sourcetreeを起動します。

![](2022-04-11-14-01-42.png)

&nbsp;&nbsp;3.2でcloneした「mylocal」ディレクトリをエクスプローラーからSourceTreeのローカルリポジトリへドラッグアンドドロップします。

![](2022-04-11-14-08-29.png)

<div style="page-break-before:always"></div>

![](2022-04-11-14-10-20.png)

「mylocal」がローカルリポジトリに登録されます。
「mylocal」をダブルクリックして<b>タブ</b>を開きます。

![](2022-04-11-14-13-11.png)

ブランチのmasterが表示されています。

<div style="page-break-before:always"></div>

![](2022-04-11-16-45-42.png)

画面左側の機能メニューです。

|メニュー|サブメニュー|機能|
|:--|:--|:--|
|ファイルステータス||ファイルの状態を表示します|
||作業コピー|ファイル作業の画面へ遷移します|
|ブランチ||ブランチを表示します|
||master|masterブランチの変更履歴を表示します|
|タグ||タグを表示します|
|||未設定のため何も表示されません|
|リモート||リモートリリポジトリを表示します|
||origin|originを表示します|
|スタッシュ||スタッシュを表示します|
|||未設定のため何も表示されません|

※スタッシュ(stash)という単語には、” こっそりしまう、隠す “といった意味があります。
今はコミットしたくない変更を一旦しまっておくのが目的です。

<div style="page-break-before:always"></div>

![](2022-04-11-17-00-06.png)

左側はGitで使用できるコマンドバー、右側は機能別ダイアログが起動します。

|コマンド|説明|
|:--|:--|
|コミット|変更を確定します|
|プル|プルのダイアログを表示します|

![](2022-04-11-17-26-56.png)

※ nidsvr01bはURLは10.47.70.10です。
|コマンド|説明|
|プッシュ|リモートリポジトリへコミット内容で更新します|

![](2022-04-11-17-29-06.png)

<div style="page-break-before:always"></div>

|コマンド|説明|
|フェッチ|リモートレポジトリのコミット履歴を取得<br>ローカルのコミット履歴をアップデートするだけで、マージしません|

![](2022-04-11-17-34-12.png)

|コマンド|説明|
|ブランチ|ブランチ操作のダイアログを表示します|

![](2022-04-11-17-22-29.png)

|コマンド|説明|
|:--|:--|
|マージ|マージ操作のダイアログを表示します|

![](2022-04-11-17-24-42.png)

<div style="page-break-before:always"></div>

|コマンド|説明|
|スタッシュ|スタッシュのダイアログを表示します|
|破棄|破棄のダイアログを表示します|
|タグ|タグのダイアログを表示します|

![](2022-04-11-17-44-36.png)

|コマンド|説明|
|Git Flow|リポジトリ初期化のダイアログを表示します|

![](2022-04-11-17-50-08.png)

|リモート||
|ターミナル||
|Explorer||

### 1.ラインブランチを作ってリリースの準備をする

&nbsp;&nbsp;NIIC(DA)ではラインブランチは「git branch」コマンドで作成しません。
&nbsp;&nbsp;代わりに、「./git_repo_make.sh」を使用して「システム.git(リモートリポジトリ)」をcloneします。

#### 1.1 ssif案件の2205RL用リポジトリを作成

> ./git_repo_make.sh <元になるリモートリポジトリ> <作成するリモートリポジトリ>

```shell
$ cd /export/home/smc/source/git/tools
$ pwd
/export/home/smc/source/git/tools
$ ./git_repo_make.sh ssif.git ssif_2205.git
$ ls ../ssif_2205.git
```

※1 作成するリモートリポジトリ名は任意の名前です。
例：ssif_test.git

※2 リポジトリを日時バックアップする場合
viで下記ファイルを編集して、リポジトリ名を追加します。
/export/home/smc/source/git/etc/backup.lst
毎日、午前0時にバックアップされます。

編集する前に、ファイルへ日付をつけてバックアップしてください。
```shell
$ cd /export/home/smc/source/git/etc
$ pwd
$ cp -ip backup.lst backup.lst.yyyymmdd
$ ls -l backup.lst.yyyymmdd
```

<div style="page-break-before:always"></div>

#### 1.2 作成したラインリポジトリのpush先

> git remote -v

```shell
$ cd /export/home/smc/source/git/ssif_2205.git
$ pwd
/export/home/smc/source/git/ssif_2205.git
$ git remote -v
origin  /export/home/smc/source/git/ssif.git (fetch)
origin  /export/home/smc/source/git/ssif.git (push)
```

&nbsp;&nbsp;push 先が「ssif.git」になっています。つまり、ssif_2205.gitのpush先は「ssif.git」になります。

※1 「./git_repo_make.sh」のおもな処理内容
nidsvr01bのgitのバージョンが古いためremoteを別途設定しています。

```shell
$ cd /export/home/smc/source/git
$ pwd
/export/home/smc/source/git
$ git clone --bare --shared ssif.git ssif_2205.git
$ cd ssif_2205.git
$ git remote add origin /export/home/smc/source/git/ssif.git/
```

![](2022-04-05-11-10-38.png)

<div style="page-break-before:always"></div>

#### 1.3 2205RL案件をローカルで編集

&nbsp;&nbsp;Windows>Git BashでGit Bashのターミナルを起動します。
&nbsp;&nbsp;1.1で作成したリモートリポジトリをローカルにcloneします。

* gitディレクトリへ移動
> cd git

![](2022-04-05-11-26-10.png)


※gitディレクトリが存在しない場合は、下記を参照して作成します。

```shell
$ pwd
/c/User/~/Documents/
$ mkdir git
$ ls git
```

* /c/User/~/Documents/gitを確認します。

> pwd

![](2022-04-05-11-27-47.png)


##### 1.3.1 ssif_2205.gitのローカルリポジトリ作成

&nbsp;&nbsp;1.1でクーロンしたssif_2205.gitをローカルにクーロンします。

> git clone ssh://10.47.70.10/export/home/smc/source/git/ssif_2205.git

※ 下記はサンプルのIPです。

![](2022-04-05-11-58-58.png)

![](2022-04-05-12-00-53.png)





