#
# $1 �٥���ݥ��ȥ�
#
GIT_DIR="/export/home/smc/source/git/"
DIF_DIR=${GIT_DIR}"diff/"
CUR_DIR=`pwd`

cd ${GIT_DIR}$1

# list
#repo=`basename $1`
git diff --diff-filter=d --name-only HEAD^ HEAD > ${DIF_DIR}$1.diff

cd ${CUR_DIR}
