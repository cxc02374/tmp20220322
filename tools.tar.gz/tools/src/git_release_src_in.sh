#!/bin/sh
#
# git_release_src_in.sh
# SR-xxxx.csv���꡼�������������֤���
#
# $1 �饤��
# $2 SR�ֹ�
# $3 ���֥ǥ��쥯�ȥ�
#
root="/export/home/smc/source/"
gitpath=$root"git/"
tmppath=$root"mng_tools/tmp/"
tagpath=$root"mng_target"
mstpath=$root"mng_tools/cfg/src_mst/"
sw="0"
OK=0
NG=1

cd $gitpath$1

# SR No.
if [ `echo $2 | cut -b 1-3` = 'SR-' ]; then
    srno=$2
else
    srno="SR-"$2
fi

echo "\n"
echo "���֥��������� ---------------------------"

# read dir and make rls dir
for FILE in `find . -type d`; do
    CNT=`echo $FILE | awk -F "/" '{print NF}'`

    # ./server/
    if [ $CNT -eq 2 ]; then
        svr=`echo $FILE | tr -d './'`
    fi

    # ./server/user/
    if [ $CNT -eq 3 ]; then
        while read line
        do

            # SR-xxxx.csv server 
            svr2=`echo $line | awk -F "," '{print $2}'`

            # release server equal
            if [ $svr = $svr2 ]; then 

                kbn=`echo $line | awk -F "," '{print $1}'`
                user=`echo $line | awk -F "," '{print $3}'`
                file=`echo $line | awk -F "," '{print $4}'`
                dir=`echo $line | awk -F "," '{print $2,$3}' | tr ' ' '/'`

                # release type
                if [ $kbn = "2" ]; then
                    type=`echo $line | awk -F "," '{print $6}' | cut -b 1-`
                else
                    type=`grep $file $mstpath"src_mst_"$svr | awk -F "," '{print $2}'`
                fi

                # release type = "S" or "SE"
                if [ $type = "S" -o $type =  "SE" ]; then

                    # release dir
                    rdir=$tagpath"/"$1"/"$dir"/release/"$srno"/"$3"/in/"`dirname $file`
                    if [ ! -d $rdir ]; then
                        mkdir -p $rdir
                    fi

                    # release file cp
                    rfile=$svr"/"$user"/"$file
                    if [ ! -f $rfile ]; then
                        echo "this file is missing : "$rfile
                    else
                        cp -p $rfile $rdir"/."
                        echo $rdir`basename $rfile`
                    fi
                fi
            fi 

        done < $tmppath$srno".csv"
    fi 
done

echo "------------------------------------------"

exit 0
