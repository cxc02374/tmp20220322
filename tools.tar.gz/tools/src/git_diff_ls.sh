#
# $1 �٥���ݥ��ȥ�
#
gitpath="/export/home/smc/source/git/"
diffs=$gitpath"diffs/"
tools=$gotpath"tools/"

cd $gitpath$1
pwd

# list
#repo=`basename $1`
git diff --diff-filter=d --name-only HEAD^ HEAD > $diffs$1.diff

cd $tools
