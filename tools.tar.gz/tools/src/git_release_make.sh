#!/bin/sh
#
# git_release_make.sh
# SR-xxxx.csv���꡼���ǥ��쥯�ȥ���������
#
# $1 �饤��
# $2 SR�ֹ�
#
root="/export/home/smc/source/"
gitpath=$root"git/"
tmppath=$root"mng_tools/tmp/"
mstpath=$root"mng_tools/cfg/src_mst/"
#srno="SR-"$2
sw="0"
OK=0
NG=2

# line dir
if [ ! -d $gitpath$1 ]; then
    mkdir $gitpath$1
fi
cd $gitpath$1

# SR No.
if [ `echo $2 | cut -b 1-3` = 'SR-' ]; then
    srno=$2
else
    srno="SR-"$2
fi

# read dir and make rls dir
for FILE in `find . -type d`; do
    CNT=`echo $FILE | awk -F "/" '{print NF}'`

    # ./server/
    if [ $CNT -eq 2 ]; then
        svr=`echo $FILE | tr -d './'`
    fi

    # ./server/user/
    if [ $CNT -eq 3 ]; then
        while read line
        do

            # SR-xxxx.csv server 
            svr2=`echo $line | awk -F "," '{print $2}'`

            # release server equal
            if [ $svr = $svr2 ]; then 

                kbn=`echo $line | awk -F "," '{print $1}'`
                user=`echo $line | awk -F "," '{print $3}'`
                file=`echo $line | awk -F "," '{print $4}'`
                dir=`echo $line | awk -F "," '{print $2,$3}' | tr ' ' '/'`

                # release type
                if [ $kbn = "2" ]; then
                    type=`echo $line | awk -F "," '{print $6}' | cut -b 1-`
                else
                    type=`grep $file $mstpath"src_mst_"$svr | awk -F "," '{print $2}'`
                fi

                # release type = "E" or "SE"
                if [ $type = "E" -o $type =  "SE" ]; then

                    # rls dir init 
                    if [ $sw = "0" ]; then 
                        if [ -d $dir"/release/"$srno"/rls" ]; then
                            rm -r $dir"/release/"$srno"/rls" 
                        fi
                        mkdir -p $dir"/release/"$srno"/rls" 
                        sw="1"
                    fi

                    # release dir
                    rdir=$dir"/release/"$srno"/rls/"`dirname $file`
                    if [ ! -d $rdir ]; then
                        mkdir -p $rdir
                    fi

                    # release file cp
                    rfile=$svr"/"$user"/"$file
                    if [ ! -f $rfile ]; then
                        echo "this file is missing : "$rfile
                    else
                        cp -p $rfile $rdir"/."
                    fi
                fi
            fi 

        done < $tmppath$srno".csv"
    fi 
done

# SR-xxxx_server_user.rls.tar.Z create

out_tar_name=$srno"_"$svr"_"$user".rls.tar"
rlsdir=$dir"/release/"$srno"/"
cd $rlsdir

if [ -f $out_tar_name ]; then
   rm -i $out_tar_name
fi

if [ ! -d ./rls ]; then
    echo "rls�ǥ��쥯�ȥ꤬¸�ߤ��ޤ���"
    return $NG
fi

tar cvf $out_tar_name ./rls > /dev/null 2>&1
if [ $? -ne $OK ]; then
    echo "��꡼����tar�ե���������˼���[$out_tar_name]"
    return $NG 
fi 

if [ -d $rlsdir"other" ]; then
    tar rvf $out_tar_name ./other > /dev/null 2>&1
    if [ $? -ne $OK ]; then
        echo "��꡼����tar�ե������other�ǥ��쥯�ȥ��ɲä˼���[$out_tar_name]" 
        return $NG
    fi
fi

if [ -f $out_tar_name".Z" ]; then
   rm -i $out_tar_name".Z"
fi

compress $out_tar_name
