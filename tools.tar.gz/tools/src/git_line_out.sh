#!/bin/sh
#
# git_line_out.sh
# �٥���ݥ��ȥ����ѹ��ե�������Ф��饤����ۤ���
# 
# $1 �٥���ݥ��ȥ�
# $2 �饤��
#
gitpath="/export/home/smc/source/git/"
diffs=$gitpath"diffs/"
tools=$gitpath"tools/"

# remote repo clone
cd $gitpath 
if [ -d tmp ]; then
    \rm -r tmp
fi
git clone $1 tmp
cd tmp
chmod -R 777 .git

# change file list
tail_id=`git log --oneline | tail -n 2 | head -n 1 | cut -b 1-7`
echo "tail_id = "$tail_id
echo $diffs$1.diff
git diff $tail_id^ HEAD  --name-only > $diffs$1.diff

# commit time stamp change
for FILE in `git ls-files`; do
    TIME=`git log --pretty=format:%ci -n1 $FILE`
    # echo $TIME' '$FILE
    STAMP=`date -d "$TIME" +"%y%m%d%H%M.%S"`
    touch -t $STAMP $FILE
done

# Line dir
cd ..
if [ ! -d $2 ]; then
    mkdir $2
fi

# file copy
cd tmp
while read line
do 

    # dir create
    dir=`dirname $line`
    # echo $dir
    if [ ! -d ../$2/$dir ]; then
        mkdir -p ../$2/$dir
    fi

    # cp file
    cp -p $line ../$2/$dir/.
 
done < $diffs$1.diff

# tmp dir remove
cd ..
\rm -r tmp

cd $tools
