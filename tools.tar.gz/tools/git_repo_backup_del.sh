#!/bin/sh
################################################################################
#
# Parameter : �ʤ�
# Outline   : /export/home/smc/source/git �ΥХå����åפκ����Ԥ�
#
# Date		Ver		Author			History
# ---------+-------+---------------+-------------------------------------------
# 22/03/25      1.0              Takayuki Ito            ADD
#
################################################################################
ROOT_DIR="/export/home/smc/source/git/"
CUR_DIR=`pwd`
BACKUP_DIR=${ROOT_DIR}"backup/"
BACKUP_LST=${ROOT_DIR}"etc/backup.lst"
LOGFILE=${ROOT_DIR}"log/git_repo_backup_del_"`date +%Y%m%d`".log"

today=`date +%Y%m%d`
target_date=`date --date "${today} 7 days ago" +%Y%m%d`

cd ${BACKUP_DIR}

(

echo "start               : "`date '+%H:%M:%S'`
echo "delete target date  : "${target_date}
 
while read line
do
    BACKUP_REPO=${line}"_"${target_date}".tar.gz "
    if [ ! -f "./"${BACKUP_REPO} ]; then
        echo "nothing backup repo : "${BACKUP_REPO}
        continue
    fi

    rm "./"${BACKUP_REPO}
    echo "delete backup repo  : "${BACKUP_REPO}

done < ${BACKUP_LST}

echo "end                 : "`date '+%H:%M:%S'`

) 2>&1 | tee -a "${LOGFILE}"

cd ${CUR_DIR}
exit 0
