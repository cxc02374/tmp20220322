#!/bin/sh
################################################################################
#
# Parameter : �ʤ�
# Outline   : /export/home/smc/source/git �ΥХå����åפ�Ԥ�
#
# Date		Ver		Author			History
# ---------+-------+---------------+-------------------------------------------
# 22/02/21      1.0              Takayuki Ito            ADD
#
################################################################################
ROOT_DIR="/export/home/smc/source/git/"
CUR_DIR=`pwd`
BACKUP_DIR=${ROOT_DIR}"backup/"
BACKUP_LST=${ROOT_DIR}"etc/backup.lst"
LOGFILE=${ROOT_DIR}"log/git_repo_backup_"`date +%Y%m%d`".log"

cd ${ROOT_DIR}

(

echo "start : "`date '+%H:%M:%S'`  

while read line
do
    if [ ! -d "./"${line} ]; then
        echo "��ݥ��ȥ� "${line}" ��¸�ߤ��ޤ���"
        continue 
    fi

    REPO=${line}"_`date +%Y%m%d`.tar.gz"
    tar cvfz ${BACKUP_DIR}${REPO} "./"${line} > /dev/null 2>&1
    echo "backup to "${BACKUP_DIR}${REPO}

done < ${BACKUP_LST}

echo "end   : "`date '+%H:%M:%S'`

) 2>&1 | tee -a "${LOGFILE}"

cd ${CUR_DIR}
exit 0
